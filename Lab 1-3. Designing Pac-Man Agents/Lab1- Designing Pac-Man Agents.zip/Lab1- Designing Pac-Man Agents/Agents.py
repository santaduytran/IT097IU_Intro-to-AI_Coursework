import random

from game import Agent
from game import Directions

class DumbAgent (Agent):
    "An agent that goes East until it can not"
    def getAction(self, state):
        "The agent always goes East"
        return Directions

class RandomAgent (Agent):
    "An agent that based on the current options and pick random action to carry out"
    def getAction(self, state):
        possibleActions = state.getLegalPacmanActions()
        print("Location: ", state.getPacmanPosition())
        print("Actions available: ", possibleActions)
        if Directions.EAST in possibleActions:
            print("Going East.")
        elif Directions.WEST in possibleActions:
            print("Going West.")
        elif Directions.SOUTH in possibleActions:
            print("Going South.")
        elif Directions.NORTH in possibleActions:
            print("Going North.")
        else:
            print("Stop Going.")
        return random.choice(possibleActions)
        "The agent does not manage to get all to the food and keep moving randomly without crashing the game"

class BetterRandomAgent (Agent):
    "An agent that never chooses 'Stop' as its action"
    def getAction(self, state):
        possibleActions = state.getLegalPacmanActions()
        possibleActions = possibleActions[:-1]
        print("Location: ", state.getPacmanPosition())
        print("Actions available: ", possibleActions)
        if Directions.EAST in possibleActions:
            print("Going East.")
        elif Directions.WEST in possibleActions:
            print("Going West.")
        elif Directions.SOUTH in possibleActions:
            print("Going South.")
        elif Directions.SOUTH in possibleActions:
            print("Going North.")
        else:
            print("Stopping")
        return random.choice(possibleActions)

class ReflexAgent (Agent):
    def getAction(self, state):
        possibleActions = state.getLegalPacmanActions()
        possibleActions = possibleActions[:-1]
        print("Location: ", state.getPacmanPosition())
        print("Actions available: ", possibleActions)
        currentNumFood = state.getNumFood()
        for action in possibleActions:
            newState = state.generatePacmanSuccessor(action)
            newNumFood = state.getNumFood()
            if newNumFood < currentNumFood:
                return action
        else:
            return random.choice(possibleActions)

