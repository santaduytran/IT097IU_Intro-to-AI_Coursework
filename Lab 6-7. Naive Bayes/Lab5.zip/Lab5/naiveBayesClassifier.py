import pandas as pd
import numpy as np
import sys

class NaiveBayesFilter:
    def __init__(self):
        self.data = []
        self.vocabulary = [] #returns tuple of unique words
        self.proba = []
        self.prob = []
        self.p_spam = 0 #Probability of Spam
        self.p_ham = 0  #Probability of Ham
        # Initiate parameters
        self.parameters_spam = {unique_word: 0 for unique_word in self.vocabulary}
        self.parameters_ham = {unique_word: 0 for unique_word in self.vocabulary}

    def fit(self, X, y):
        "*** YOUR CODE HERE ***"
        return self.data

    def predict_proba(self, X, y):
        "*** YOUR CODE HERE ***"
        return self.proba

